package com.example.gps72;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    GpsView gv;
    LocationManager lm;
    SensorManager sm;
    Handler h = new Handler(Looper.getMainLooper());
    boolean started = false;
    float decl = 0;

    LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            try {
                decl = new GeomagneticField((float) l.getLatitude(), (float) l.getLongitude(), (float) l.getAltitude(), System.currentTimeMillis()).getDeclination();
            } catch (Exception e) { }
            gv.onLoc(l);
        }
        public void onStatusChanged(String p, int s, Bundle b) { }
        public void onProviderEnabled(String p) { gv.gerr = 0; }
        public void onProviderDisabled(String p) { gv.gerr = 2; gv.postInvalidate(); }
    };

    GnssStatus.Callback gcb = new GnssStatus.Callback() {
        public void onSatelliteStatusChanged(GnssStatus s) {
            int n = Math.min(s.getSatelliteCount(), 24);
            int[] id = new int[n];
            float[] az = new float[n], el = new float[n], cn = new float[n];
            boolean[] us = new boolean[n];
            for (int i = 0; i < n; i++) {
                id[i] = s.getSvid(i);
                az[i] = s.getAzimuthDegrees(i);
                el[i] = s.getElevationDegrees(i);
                cn[i] = s.getCn0DbHz(i);
                us[i] = s.usedInFix(i);
            }
            gv.setSats(n, id, az, el, cn, us);
        }
    };

    SensorEventListener sl = new SensorEventListener() {
        public void onSensorChanged(SensorEvent e) {
            float[] r = new float[9], o = new float[3];
            SensorManager.getRotationMatrixFromVector(r, e.values);
            SensorManager.getOrientation(r, o);
            if (Math.abs(o[1]) > 1.0f) {
                float[] r2 = new float[9];
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2);
                SensorManager.getOrientation(r2, o);
            }
            float hd = (float) Math.toDegrees(o[0]) + decl;
            gv.setCompass(((hd % 360) + 360) % 360);
        }
        public void onAccuracyChanged(Sensor s, int a) { }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        gv = new GpsView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF161616);
        root.setPadding(12, 12, 12, 12);
        root.addView(gv, new LinearLayout.LayoutParams(-1, 0, 3.3f));
        LinearLayout kp = new LinearLayout(this);
        kp.setOrientation(LinearLayout.VERTICAL);
        root.addView(kp, new LinearLayout.LayoutParams(-1, 0, 2.4f));
        String[][] rows = {
                {"IN:zin", "OUT:zout", "MENU:menu"},
                {"GOTO:goto", "\u25B2:up", "PAGE:page"},
                {"\u25C4:left", "\u25BC:down", "\u25BA:right"},
                {"\uD83D\uDCA1:light", "QUIT:quit", "ENTER:enter"}};
        for (String[] row : rows) {
            LinearLayout lr = new LinearLayout(this);
            lr.setOrientation(LinearLayout.HORIZONTAL);
            kp.addView(lr, new LinearLayout.LayoutParams(-1, 0, 1f));
            for (String d : row) {
                String[] p = d.split(":");
                lr.addView(mk(p[0], p[1]), new LinearLayout.LayoutParams(0, -1, 1f));
            }
        }
        setContentView(root);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    Button mk(String t, final String k) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(15);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2A2A2A);
        g.setCornerRadius(40);
        g.setStroke(2, 0xFF555555);
        bt.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
        lp.setMargins(6, 6, 6, 6);
        bt.setLayoutParams(lp);
        final boolean lg = k.equals("goto") || k.equals("enter") || k.equals("light");
        final boolean[] fired = {false};
        final Runnable lr = new Runnable() {
            public void run() { fired[0] = true; gv.press(k, true); }
        };
        bt.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setPressed(true);
                    fired[0] = false;
                    if (lg) h.postDelayed(lr, 900); else gv.press(k, false);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setPressed(false);
                    if (lg) {
                        h.removeCallbacks(lr);
                        if (!fired[0] && a == MotionEvent.ACTION_UP) gv.press(k, false);
                    }
                }
                return true;
            }
        });
        return bt;
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        startAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        startAll();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { lm.removeUpdates(ll); lm.unregisterGnssStatusCallback(gcb); } catch (Exception e) { }
        sm.unregisterListener(sl);
        started = false;
    }

    @SuppressLint("MissingPermission")
    void startAll() {
        if (started) return;
        Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rv != null) sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gv.gerr = 1;
            gv.postInvalidate();
            return;
        }
        gv.gerr = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? 0 : 2;
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, ll);
            lm.registerGnssStatusCallback(gcb, h);
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            started = true;
        } catch (Exception e) {
            gv.gerr = 1;
        }
        gv.postInvalidate();
    }
}
