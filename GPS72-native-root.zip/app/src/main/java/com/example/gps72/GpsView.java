package com.example.gps72;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class GpsView extends View {
    static class Wp { String n; double la, lo; Wp(String n, double a, double b) { this.n = n; la = a; lo = b; } }
    static class Ui { int t, m, sel, c; char[] n; }

    static final int[] ZM = {50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000};
    static final String CH = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static final String[] UN = {"Metric", "Statute", "Nautical"};
    static final int L = 0, C = 1, R = 2;

    public boolean on;
    public int gerr;
    public double lat, lon, alt;
    public float spd, trk, acc, cmp;
    public long lastFix, cmpT;
    boolean hasAlt, bl = true;
    long t0, mt;
    int page, zi = 3, un, pf, con = 6, ms, go = -1;
    double trip;
    String msg = "";
    Ui ui;
    ArrayList<Wp> wps = new ArrayList<>();
    ArrayList<double[]> tk = new ArrayList<>();
    int sn;
    int[] sid = new int[0];
    float[] saz = new float[0], sel = new float[0], scn = new float[0];
    boolean[] sus = new boolean[0];
    Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    Canvas c;
    SharedPreferences sp;
    Handler h = new Handler(Looper.getMainLooper());

    public GpsView(Context x) {
        super(x);
        P.setTypeface(Typeface.MONOSPACE);
        sp = x.getSharedPreferences("g72", 0);
        un = sp.getInt("un", 0); pf = sp.getInt("pf", 0); con = sp.getInt("con", 6); bl = sp.getBoolean("bl", true);
        try {
            for (String s : sp.getString("wps", "").split(";")) {
                if (s.isEmpty()) continue;
                String[] a = s.split(",");
                wps.add(new Wp(a[0], Double.parseDouble(a[1]), Double.parseDouble(a[2])));
            }
        } catch (Exception e) { wps.clear(); }
        h.postDelayed(new Runnable() { public void run() { invalidate(); h.postDelayed(this, 1000); } }, 1000);
    }

    void save() {
        StringBuilder b = new StringBuilder();
        for (Wp w : wps) b.append(w.n).append(',').append(w.la).append(',').append(w.lo).append(';');
        sp.edit().putInt("un", un).putInt("pf", pf).putInt("con", con).putBoolean("bl", bl).putString("wps", b.toString()).apply();
    }

    // ---------- data in ----------
    public void onLoc(Location l) {
        long now = System.currentTimeMillis();
        lat = l.getLatitude(); lon = l.getLongitude();
        hasAlt = l.hasAltitude(); if (hasAlt) alt = l.getAltitude();
        acc = l.getAccuracy(); spd = l.hasSpeed() ? l.getSpeed() : 0; lastFix = now; gerr = 0;
        if (l.hasBearing() && spd > 1 && now - cmpT > 2000) trk = l.getBearing();
        double[] last = tk.isEmpty() ? null : tk.get(tk.size() - 1);
        if (last == null || dist(last[0], last[1], lat, lon) > 4) {
            if (last != null) trip += dist(last[0], last[1], lat, lon);
            tk.add(new double[]{lat, lon});
            if (tk.size() > 600) tk.remove(0);
        }
        if (go >= 0 && go < wps.size() && dist(lat, lon, wps.get(go).la, wps.get(go).lo) < Math.max(15, acc)) {
            toast("Arrived at " + wps.get(go).n); go = -1;
        }
        postInvalidate();
    }

    public void setCompass(float hd) {
        float d = ((hd - cmp + 540) % 360) - 180;
        cmp = cmpT == 0 ? hd : (cmp + d * 0.25f + 360) % 360;
        cmpT = System.currentTimeMillis();
        trk = cmp;
        postInvalidate();
    }

    public void setSats(int n, int[] id, float[] az, float[] el, float[] cn, boolean[] us) {
        sn = n; sid = id; saz = az; sel = el; scn = cn; sus = us; postInvalidate();
    }

    void toast(String s) { msg = s; mt = System.currentTimeMillis() + 2000; postInvalidate(); }

    // ---------- helpers ----------
    static double dist(double a, double b, double c, double d) { float[] r = new float[2]; Location.distanceBetween(a, b, c, d, r); return r[0]; }
    static double brg(double a, double b, double c, double d) { float[] r = new float[2]; Location.distanceBetween(a, b, c, d, r); return (r[1] + 360) % 360; }
    int fix() { return !on ? 0 : (System.currentTimeMillis() - lastFix < 10000 && lastFix > 0) ? (hasAlt ? 3 : 2) : 0; }
    String fd(double m) {
        if (un == 0) return m < 1000 ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, m < 10000 ? "%.2fkm" : "%.1fkm", m / 1000);
        double f = m * 3.281;
        if (un == 1) return f < 1000 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, "%.2fmi", m / 1609.34);
        return m < 185 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, "%.2fnm", m / 1852);
    }
    String fs(double v) { return un == 0 ? String.format(Locale.US, "%.1fkm/h", v * 3.6) : un == 1 ? String.format(Locale.US, "%.1fmph", v * 2.237) : String.format(Locale.US, "%.1fkt", v * 1.944); }
    String fa(double m) { return un == 0 ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, "%.0fft", m * 3.281); }
    String fl(double v, boolean la) {
        if (lastFix == 0) return "-----";
        String hh = la ? (v >= 0 ? "N" : "S") : (v >= 0 ? "E" : "W");
        double a = Math.abs(v);
        if (pf == 1) return hh + " " + String.format(Locale.US, "%.5f", a) + "\u00B0";
        int d = (int) a;
        return hh + " " + String.format(Locale.US, la ? "%02d" : "%03d", d) + "\u00B0" + String.format(Locale.US, "%06.3f", (a - d) * 60) + "'";
    }
    String ete() {
        if (go < 0 || go >= wps.size() || spd < 0.3) return "--:--:--";
        int s = (int) (dist(lat, lon, wps.get(go).la, wps.get(go).lo) / spd);
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60);
    }
    int ia() { return ((int) (255 * (0.4 + con * 0.06))) << 24; }
    void ink() { P.setColor(ia() | 0x14200C); }
    void bgc() { P.setColor(bl ? 0xFFA9CC7E : 0xFF93A578); }
    void T(String s, float x, float y, float z, int al, boolean b) {
        P.setStyle(Paint.Style.FILL); P.setTextSize(z); P.setFakeBoldText(b);
        P.setTextAlign(al == 0 ? Paint.Align.LEFT : al == 1 ? Paint.Align.CENTER : Paint.Align.RIGHT);
        c.drawText(s, x, y + z * 0.8f, P);
    }
    void fr(float x, float y, float w, float hh) { P.setStyle(Paint.Style.FILL); c.drawRect(x, y, x + w, y + hh, P); }
    void sr(float x, float y, float w, float hh) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawRect(x, y, x + w, y + hh, P); }
    void ln(float a, float b, float x, float y) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawLine(a, b, x, y, P); }
    void circ(float x, float y, float r) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawCircle(x, y, r, P); }
    void row(int i, String s, boolean sel, float y0) {
        float y = y0 + i * 20;
        if (sel) { fr(2, y, 156, 18); bgc(); T(s, 6, y + 4, 11, L, false); ink(); } else T(s, 6, y + 4, 11, L, false);
    }
    float[] proj(double la, double lo) {
        double p = 60.0 / ZM[zi];
        return new float[]{(float) (80 + (lo - lon) * Math.cos(Math.toRadians(lat)) * 111320 * p), (float) (125 - (la - lat) * 110540 * p)};
    }

    // ---------- drawing ----------
    @Override
    protected void onDraw(Canvas cv) {
        c = cv;
        int W = getWidth(), H = getHeight();
        float sc = Math.min(W / 160f, H / 240f);
        c.save();
        c.translate((W - 160 * sc) / 2, (H - 240 * sc) / 2);
        c.scale(sc, sc);
        c.clipRect(0, 0, 160, 240);
        draw();
        c.restore();
    }

    void draw() {
        P.setPathEffect(null);
        if (on) bgc(); else P.setColor(0xFF4A4D31);
        P.setStyle(Paint.Style.FILL); c.drawRect(0, 0, 160, 240, P);
        if (!on) return;
        ink();
        int f = fix();
        long now = System.currentTimeMillis();
        if (now - t0 < 2500) {
            T("GARMIN", 80, 70, 24, C, true); T("GPS 72", 80, 104, 18, C, true); T("Hand-held Navigator", 80, 140, 9, C, false);
            return;
        }
        if (page == 0) {
            T("SATELLITE", 80, 2, 8, C, false);
            float cx = 80, cy = 70, r = 50;
            circ(cx, cy, r); circ(cx, cy, r / 2); ln(cx - r, cy, cx + r, cy); ln(cx, cy - r, cx, cy + r);
            T("N", cx, cy - r - 10, 8, C, false);
            for (int i = 0; i < sn; i++) {
                float q = (90 - sel[i]) / 90f * r;
                float x = cx + q * (float) Math.sin(Math.toRadians(saz[i])), y = cy - q * (float) Math.cos(Math.toRadians(saz[i]));
                if (sus[i]) { fr(x - 7, y - 5, 14, 10); bgc(); T("" + sid[i], x, y - 4, 8, C, false); ink(); }
                else { sr(x - 7, y - 5, 14, 10); T("" + sid[i], x, y - 4, 8, C, false); }
            }
            int cnt = Math.min(sn, 12);
            for (int i = 0; i < cnt; i++) {
                float x = 6 + i * 12.5f, hh = Math.min(scn[i], 50) * 0.9f;
                if (hh > 1) fr(x, 200 - hh, 9, hh); else fr(x, 199, 9, 1);
                T("" + sid[i], x + 4.5f, 203, 7, C, false);
            }
            fr(4, 196, 152, 1);
            T(f == 0 ? "Acquiring Satellites" : f == 2 ? "2D GPS Location" : "3D GPS Location", 80, 216, 10, C, true);
            T(gerr == 1 ? "Location permission denied" : gerr == 2 ? "GPS is turned off" : f > 0 ? "REAL GPS  EPE " + (int) acc + "m" : "Waiting for GPS...", 80, 229, 8, C, false);
        } else if (page == 1) {
            c.save(); c.clipRect(0, 12, 160, 226);
            Path pa = new Path();
            for (int i = 0; i < tk.size(); i++) { float[] q = proj(tk.get(i)[0], tk.get(i)[1]); if (i == 0) pa.moveTo(q[0], q[1]); else pa.lineTo(q[0], q[1]); }
            P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); P.setPathEffect(new DashPathEffect(new float[]{2, 2}, 0)); c.drawPath(pa, P); P.setPathEffect(null);
            if (go >= 0 && go < wps.size()) { float[] q = proj(wps.get(go).la, wps.get(go).lo); P.setStrokeWidth(2); c.drawLine(80, 125, q[0], q[1], P); P.setStrokeWidth(1); }
            for (int i = 0; i < wps.size(); i++) {
                float[] q = proj(wps.get(i).la, wps.get(i).lo);
                Path d = new Path(); d.moveTo(q[0], q[1] - 5); d.lineTo(q[0] + 5, q[1]); d.lineTo(q[0], q[1] + 5); d.lineTo(q[0] - 5, q[1]); d.close();
                P.setStyle(i == go ? Paint.Style.FILL : Paint.Style.STROKE); c.drawPath(d, P);
                T(wps.get(i).n, q[0] + 7, q[1] - 4, 8, L, false);
            }
            c.save(); c.translate(80, 125); c.rotate(trk);
            Path ar = new Path(); ar.moveTo(0, -8); ar.lineTo(6, 7); ar.lineTo(0, 3); ar.lineTo(-6, 7); ar.close();
            P.setStyle(Paint.Style.FILL); c.drawPath(ar, P); c.restore(); c.restore();
            fr(0, 12, 160, 1); T("N\u2191", 156, 15, 8, R, false);
            T(go >= 0 && go < wps.size() ? "\u2192" + wps.get(go).n + " " + fd(dist(lat, lon, wps.get(go).la, wps.get(go).lo)) : "MAP", 3, 15, 8, L, false);
            fr(4, 230, 60, 2); fr(4, 227, 1, 5); fr(63, 227, 1, 5); T(fd(ZM[zi]), 68, 226, 9, L, false);
            if (f == 0) T("NO FIX", 156, 226, 9, R, false);
        } else if (page == 2) {
            T("HIGHWAY", 80, 2, 8, C, false);
            if (go < 0 || go >= wps.size()) { T("No Active GOTO", 80, 100, 11, C, true); T("Press GOTO to select", 80, 120, 9, C, false); }
            else {
                Wp w = wps.get(go);
                double b = brg(lat, lon, w.la, w.lo), d = dist(lat, lon, w.la, w.lo), df = ((b - trk + 540) % 360) - 180;
                T("TO  " + w.n, 4, 14, 11, L, true); T("DST " + fd(d), 4, 30, 11, L, false);
                T("BRG " + (int) b + "\u00B0", 4, 46, 11, L, false); T("ETE " + ete(), 4, 62, 11, L, false); fr(0, 80, 160, 1);
                float vx = (float) (80 + Math.max(-70, Math.min(70, df * 1.6)));
                ln(20, 215, vx - 6, 100); ln(140, 215, vx + 6, 100);
                P.setPathEffect(new DashPathEffect(new float[]{6, 6}, 0)); ln(80, 215, vx, 100); P.setPathEffect(null); fr(0, 100, 160, 1);
                T(Math.abs(df) < 5 ? "ON COURSE" : df > 0 ? "TURN RIGHT " + (int) Math.abs(df) + "\u00B0" : "TURN LEFT " + (int) Math.abs(df) + "\u00B0", 80, 86, 9, C, true);
            }
            fr(0, 218, 160, 1); T("SPD " + fs(spd), 4, 224, 10, L, false); T("TRK " + (int) trk + "\u00B0", 156, 224, 10, R, false);
        } else if (page == 3) {
            T("POSITION", 80, 2, 8, C, false);
            float cx = 80, cy = 60, r = 40;
            circ(cx, cy, r);
            for (int a = 0; a < 360; a += 30) {
                double g = Math.toRadians(a - trk);
                float s = (float) Math.sin(g), co = (float) -Math.cos(g);
                if (a % 90 == 0) T("" + "NESW".charAt(a / 90), cx + s * (r - 9), cy + co * (r - 9) - 4, 9, C, true);
                else ln(cx + s * (r - 4), cy + co * (r - 4), cx + s * r, cy + co * r);
            }
            Path tr = new Path(); tr.moveTo(cx, cy - r - 8); tr.lineTo(cx + 5, cy - r); tr.lineTo(cx - 5, cy - r); tr.close(); P.setStyle(Paint.Style.FILL); c.drawPath(tr, P);
            T((int) trk + "\u00B0", cx, cy - 6, 12, C, true);
            T(fl(lat, true), 80, 112, 12, C, true); T(fl(lon, false), 80, 128, 12, C, true); fr(4, 146, 152, 1);
            T("ALT " + fa(alt), 4, 152, 10, L, false); T("SPD " + fs(spd), 4, 166, 10, L, false); T("TRIP " + fd(trip), 4, 180, 10, L, false);
            T(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()), 4, 198, 12, L, true);
            T(new SimpleDateFormat("dd/MM/yyyy", Locale.US).format(new Date()), 4, 214, 10, L, false);
            T(f == 0 ? "NO FIX" : f == 2 ? "2D" : "3D", 156, 214, 10, R, true);
        } else {
            T("MAIN MENU", 80, 3, 10, C, true);
            String[] it = {"Waypoints (" + wps.size() + ")", "Clear Track", "Reset Trip", "Units: " + UN[un], "Pos: " + (pf == 1 ? "ddd.ddddd\u00B0" : "ddd\u00B0mm.mmm'"), "Contrast: " + con, "Backlight: " + (bl ? "On" : "Off"), "Stop GOTO"};
            for (int i = 0; i < it.length; i++) row(i, it[i], i == ms, 16);
            T("\u25C4 \u25BA change  ENTER select", 80, 208, 8, C, false); T("Garmin GPS 72  v2.50", 80, 222, 8, C, false);
        }
        if (ui != null) {
            bgc(); fr(0, 0, 160, 240); ink();
            if (ui.t == 1) {
                T(ui.m == 1 ? "WAYPOINTS" : "GOTO WAYPOINT", 80, 3, 10, C, true);
                if (wps.isEmpty()) T("No waypoints", 80, 100, 10, C, false);
                int o = Math.max(0, Math.min(ui.sel - 4, wps.size() - 9));
                for (int i = o; i < Math.min(wps.size(), o + 9); i++) row(i - o, String.format("%-7s", wps.get(i).n) + fd(dist(lat, lon, wps.get(i).la, wps.get(i).lo)), i == ui.sel, 16);
                T(ui.m == 1 ? "ENTER:GOTO MENU:DELETE" : "ENTER:GOTO  QUIT:BACK", 80, 222, 8, C, false);
            } else {
                fr(0, 0, 160, 16); bgc(); T("MARK POSITION", 80, 3, 10, C, true); ink(); T("Name", 80, 50, 9, C, false);
                for (int i = 0; i < 6; i++) {
                    float x = 80 + (i - 2.5f) * 16;
                    if (i == ui.c) { fr(x - 8, 68, 16, 22); bgc(); T("" + ui.n[i], x, 70, 16, C, true); ink(); } else T("" + ui.n[i], x, 70, 16, C, true);
                }
                T(fl(lat, true), 80, 110, 10, C, false); T(fl(lon, false), 80, 124, 10, C, false);
                T("\u25B2\u25BC char  \u25C4\u25BA move", 80, 160, 9, C, false); T("ENTER = OK   QUIT = CANCEL", 80, 200, 8, C, false);
            }
        }
        if (now < mt) { ink(); fr(10, 95, 140, 34); bgc(); T(msg, 80, 106, 10, C, true); }
    }

    // ---------- keys ----------
    void pwr() {
        on = !on;
        if (on) { t0 = System.currentTimeMillis(); page = 0; ui = null; }
        postInvalidate();
    }

    void menuAct(int i, int d) {
        if (i == 0) { ui = new Ui(); ui.t = 1; ui.m = 1; }
        else if (i == 1) { tk.clear(); toast("Track cleared"); }
        else if (i == 2) { trip = 0; toast("Trip reset"); }
        else if (i == 3) un = (un + (d == 0 ? 1 : d) + 3) % 3;
        else if (i == 4) pf ^= 1;
        else if (i == 5) con = Math.max(0, Math.min(10, con + (d == 0 ? 1 : d)));
        else if (i == 6) bl = !bl;
        else if (i == 7) { go = -1; toast("GOTO stopped"); }
        save();
    }

    void mark(String n) { wps.add(new Wp(n, lat, lon)); save(); }

    public void press(String k, boolean lg) {
        if (k.equals("light") && lg) { pwr(); return; }
        if (!on) return;
        if (System.currentTimeMillis() - t0 < 2500) t0 = 0;
        if (k.equals("light")) { bl = !bl; save(); postInvalidate(); return; }
        int dy = k.equals("up") ? -1 : k.equals("down") ? 1 : 0;
        if (ui != null) {
            if (k.equals("quit")) ui = null;
            else if (ui.t == 1) {
                int n = wps.size();
                if (dy != 0) ui.sel = Math.max(0, Math.min(n - 1, ui.sel + dy));
                else if (k.equals("enter") && n > 0) { go = ui.sel; ui = null; page = 2; toast("GOTO " + wps.get(go).n); }
                else if (k.equals("menu") && ui.m == 1 && n > 0) {
                    if (go == ui.sel) go = -1; else if (go > ui.sel) go--;
                    wps.remove(ui.sel); ui.sel = Math.max(0, ui.sel - 1); save();
                }
            } else {
                if (k.equals("left")) ui.c = Math.max(0, ui.c - 1);
                else if (k.equals("right")) ui.c = Math.min(5, ui.c + 1);
                else if (dy != 0) { int i = CH.indexOf(ui.n[ui.c]); ui.n[ui.c] = CH.charAt((i - dy + 36) % 36); }
                else if (k.equals("enter")) { String nm = new String(ui.n); mark(nm); ui = null; toast("Saved " + nm); }
            }
            postInvalidate(); return;
        }
        if (k.equals("page")) page = (page + 1) % 5;
        else if (k.equals("quit")) page = (page + 4) % 5;
        else if (k.equals("menu")) page = page == 4 ? 1 : 4;
        else if (k.equals("zin") && page == 1) zi = Math.max(0, zi - 1);
        else if (k.equals("zout") && page == 1) zi = Math.min(ZM.length - 1, zi + 1);
        else if (k.equals("goto")) {
            if (lg) {
                if (lastFix == 0) { toast("No GPS fix"); return; }
                mark("MOB"); go = wps.size() - 1; page = 2; toast("MOB - GOTO active");
            } else if (wps.isEmpty()) toast("No waypoints");
            else { ui = new Ui(); ui.t = 1; ui.m = 0; ui.sel = Math.max(0, go); }
        } else if (k.equals("enter")) {
            if (lg) {
                if (lastFix == 0) { toast("No GPS fix"); return; }
                ui = new Ui(); ui.t = 2; ui.n = String.format(Locale.US, "WPT%03d", wps.size() + 1).toCharArray();
                ui.c = 5;
            } else if (page == 4) menuAct(ms, 0);
        } else if (page == 4) {
            if (dy != 0) ms = (ms + dy + 8) % 8;
            else if (k.equals("left") || k.equals("right")) menuAct(ms, k.equals("left") ? -1 : 1);
        }
        postInvalidate();
    }
}
