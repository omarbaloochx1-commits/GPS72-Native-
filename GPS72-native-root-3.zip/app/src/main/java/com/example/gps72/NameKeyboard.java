package com.example.gps72;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NameKeyboard extends Dialog {
    public interface Done { void ok(String s); }

    static final String[] EN = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
    static final String[] BL = {"ابپتٹثجچحخ", "دڈذرڑزژسشص", "ضطظعغفقکگل", "منںوہھءئیے", "ێۆآ-."};
    static final String DIG = "1234567890";
    StringBuilder sb;
    boolean bal, shift;
    TextView tv;
    LinearLayout keys;
    Done cb;
    float d;

    public NameKeyboard(Context c, String init, Done cb) {
        super(c);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        sb = new StringBuilder(init == null ? "" : init);
        this.cb = cb;
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(getContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1B1B1B);
        int p = (int) (8 * d);
        root.setPadding(p, p, p, p);
        tv = new TextView(getContext());
        tv.setTextSize(24);
        tv.setTextColor(0xFF14200C);
        tv.setGravity(Gravity.CENTER);
        tv.setHint("Name");
        tv.setSingleLine(true);
        tv.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFA9CC7E);
        g.setCornerRadius(8 * d);
        tv.setBackground(g);
        tv.setPadding(p, p, p, p);
        root.addView(tv, new LinearLayout.LayoutParams(-1, -2));
        keys = new LinearLayout(getContext());
        keys.setOrientation(LinearLayout.VERTICAL);
        root.addView(keys, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        build();
        refresh();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Window w = getWindow();
        if (w != null) {
            w.setLayout(-1, -2);
            w.setGravity(Gravity.BOTTOM);
            w.setBackgroundDrawable(new ColorDrawable(0xFF1B1B1B));
        }
    }

    LinearLayout row() {
        LinearLayout r = new LinearLayout(getContext());
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        keys.addView(r, new LinearLayout.LayoutParams(-1, -2));
        return r;
    }

    Button btn(String t, float w, boolean hi, final Runnable r) {
        Button b = new Button(getContext());
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(18);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(hi ? 0xFF3C6E3C : 0xFF333333);
        g.setCornerRadius(8 * d);
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (46 * d), w);
        lp.setMargins(2, 2, 2, 2);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { r.run(); }
        });
        return b;
    }

    void build() {
        keys.removeAllViews();
        LinearLayout lr = row();
        lr.addView(btn("English", 1, !bal, new Runnable() { public void run() { bal = false; build(); } }));
        lr.addView(btn("\u0628\u0644\u0648\u0686\u06CC", 1, bal, new Runnable() { public void run() { bal = true; build(); } }));
        LinearLayout dr = row();
        for (int i = 0; i < DIG.length(); i++) dr.addView(btn("" + DIG.charAt(i), 1, false, typer("" + DIG.charAt(i))));
        String[] L = bal ? BL : EN;
        for (String s : L) {
            LinearLayout r = row();
            for (int i = 0; i < s.length(); i++) {
                String ch = "" + s.charAt(i);
                if (!bal && shift) ch = ch.toUpperCase();
                r.addView(btn(ch, 1, false, typer(ch)));
            }
        }
        LinearLayout br = row();
        if (!bal) br.addView(btn("Aa", 1.5f, shift, new Runnable() { public void run() { shift = !shift; build(); } }));
        br.addView(btn("space", 4, false, typer(" ")));
        br.addView(btn("DEL", 1.5f, false, new Runnable() { public void run() { if (sb.length() > 0) sb.setLength(sb.length() - 1); refresh(); } }));
        LinearLayout fr = row();
        fr.addView(btn("Cancel", 1, false, new Runnable() { public void run() { dismiss(); } }));
        fr.addView(btn("CLR", 1, false, new Runnable() { public void run() { sb.setLength(0); refresh(); } }));
        fr.addView(btn("OK", 2, true, new Runnable() {
            public void run() {
                String s = sb.toString().trim();
                if (s.isEmpty()) return;
                dismiss();
                if (cb != null) cb.ok(s);
            }
        }));
    }

    Runnable typer(final String s) {
        return new Runnable() {
            public void run() {
                if (sb.length() < 14) {
                    sb.append(s);
                    if (!bal && shift) { shift = false; build(); }
                    refresh();
                }
            }
        };
    }

    void refresh() { tv.setText(sb.toString()); }
}
